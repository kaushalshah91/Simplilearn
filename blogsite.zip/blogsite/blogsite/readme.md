Setup:

1. Setup a blogging site using the following:
    Bootstrap
    GitHub
    Sprint Plan on Jira for Project Tracking
2. It should accept blog entries and display submitted blogs.
3. Use localStorage since backend is not integrated in this project.


Create a project with a basic bootstrap theme.
Include an accordion, mobile site layout and collapsible menu.
It should have the following pages:
1. home: Should show all blogs in the localStorage
2. post: Should show an individual post when card is clicked
3. create: This will allow a form entry to create a blog


The form should allow adding a blog entry to the localStorage variable and take all items to it.
It should take current localStorage entries and append to them.
For now, delete will not be added to the project. Clearing Application -> LocalStorage -> siteStorage key will need to be done
Javascript validations are not added to the forms. The user is expected to add some dummy data.
Example:
1. Masthead image: https://images.pexels.com/photos/2325446/pexels-photo-2325446.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2
2. Blog Title: Hot Air Balloon Festival.
3. Blog sub-title: Everyone is welcome to join in the celebration.
4. Author: Author #1.
5. Blog Body:
        <h3 class="f5 cl-orange mb16">History, Purpose and Usage</h3>
        <p class="f4 cl-white mt0 mb16"><em>Lorem ipsum</em>, or <em>lipsum</em> as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's <em>De Finibus Bonorum et Malorum</em> for use in a type specimen book. It usually begins with:
        </p>
        <blockquote class="page-section__blockquote">“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.”</blockquote>
        <p class="f4 cl-white mv16">The purpose of <em>lorem ipsum</em> is to create a natural looking block of text (sentence, paragraph, page, etc.) that doesn't distract from the layout. A practice not without <a href="#controversy" title="Controversy in the Design World">controversy</a>, laying out pages with meaningless filler text can be very useful when the focus is meant to be on design, not content.