import { site } from './modules/interface.js';

var siteStorage = JSON.parse(window.localStorage.getItem("siteStorage"));
//console.log(siteStorage);

if (siteStorage == null || siteStorage == undefined || siteStorage == "") {
    console.log("Nothing block");
    window.localStorage.setItem('siteStorage', JSON.stringify(site));
    siteStorage = JSON.parse(window.localStorage.getItem("siteStorage"));
}

window.addEventListener("load", replaceHtml);

function replaceHtml() {
    var container = document.getElementById('accordion');
    var blogArray = Object.values(siteStorage.blogs);

    if(window.location.href.indexOf("post")> -1){
        var id=getParameterByName('id')
        if(document.getElementById("blogImage")){
            document.getElementById("blogImage").src = blogArray[id].blogImage;
        }
        if(document.getElementById("blogTitle")){
            document.getElementById("blogTitle").innerHTML = siteStorage.blogs[id].blogTitle;
        }
        if(document.getElementById("blogSubTitle")){
            document.getElementById("blogSubTitle").innerHTML = siteStorage.blogs[id].blogSubTitle;
        }
        if(document.getElementById("author")){
            document.getElementById("author").innerHTML = siteStorage.blogs[id].author;
        }
        if(document.getElementById("blogBody")){
            document.getElementById("blogBody").innerHTML = siteStorage.blogs[id].blogBody;
        }
    }
    if(window.location.href.indexOf("index")> -1){
        blogArray.forEach((data, id) => {
            // Create card element
            const card = document.createElement('div');
            card.classList = 'accordion-item';


            const content = `
            <div class="accordion-item">
             <h2 class="accordion-header" id="">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapse-${id}" aria-expanded="true" aria-controls="collapse-${id}"
                id="blogTitle">
                ${data.blogTitle}
                </button>
             </h2>
            <div id="collapse-${id}" class="accordion-collapse collapse" aria-labelledby="heading-${id}"
            data-bs-parent="#accordion">
            <div class="accordion-body">
                <a style="text-decoration:none;color:blue;cursor:pointer" onClick="window.open('post.html?id=${id}','_self')">
                <h3 id="blogTitle">${data.blogTitle}</h3>
                </a>
                <h4 id="blogSubTitle" class="subtitle">${data.blogSubTitle}
                </h4>
                <span class="meta">
                    Posted by
                    <a id="author" href="#!">${data.author}</a>
                </span>
            </div>
        </div>
    </div>
            `
            // Append newyly created card element to the container
            container.innerHTML += content;
        })
    }
}

document.getElementById("addPost")?.addEventListener('submit', e => {
    e.preventDefault();
    var blog = {
        blogImage: document.getElementById("inputBloghead")?.value != null ? document.getElementById("inputBloghead").value : "",
        blogTitle: document.getElementById("inputTitle")?.value != null ? document.getElementById("inputTitle").value : "",
        blogSubTitle: document.getElementById("inputSubTitle")?.value != null ? document.getElementById("inputSubTitle").value : "",
        author: document.getElementById("inputAuthor")?.value != null ? document.getElementById("inputAuthor").value : "",
        blogBody:document.getElementById("inputBlogBody")?.value != null ? document.getElementById("inputBlogBody").value : ""
    }
    siteStorage.blogs.push(blog);
    window.localStorage.setItem('siteStorage', JSON.stringify(siteStorage));
    window.open('index.html',"_self")
  });

  function getParameterByName(name, url = window.location.href) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}