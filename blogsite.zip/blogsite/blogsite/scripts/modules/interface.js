var site = {
    "blogs": [
        {
            blogImage: "https://simplifaster.com/wp-content/uploads/2023/03/Wickets-Header.jpg",
            blogTitle: "Using Wickets to Train Sprint Mechanics for Team Sport Athletes",
            blogSubTitle: "Speed is the most important metric to develop in all athletes",
            author: "Author",
            blogBody: `
                            <p>As a high school football coach, I work with young people with a wide range of athletic abilities and body types. With all types of athletes, wickets are a fantastic tool to create elite sprint shapes. My work is inspired and influenced by the brilliance of Tony Holler, Chris Korfist, Barry Ross, Jimmy Radcliffe, Brian Kula, Dr. Ken Clark, Brad Dixon, JT Ayers, Joey Guarascio, and others. I did not invent the wheel—all credit goes to those who have come before.</p>
                            <p>I am always struck by the beauty of speed. Seeing athletes sprint with proper form is a joy to behold. Seeing that speed translate to the playing field is fulfilling. As a lifelong sprinter, I can also confirm that sprinting through wickets is a beautiful feeling.</p>
                            <p>I believe that speed is the most important attribute for all athletes. In any sport, at any position, being faster makes you better. In any athletic contest, being faster creates two essential elements: space and time. Speed gives an athlete the ability to create or close space while also enabling the athlete to read and process longer before reacting.</p>
                `
        },
        {
            blogImage: "https://simplifaster.com/wp-content/uploads/2023/03/Min-Intervals.jpg",
            blogTitle: "Keep Your Cardio Simple with Minute Intervals",
            blogSubTitle: "Sprinting is good for conditioning and is obviously more “sports-specific” for running sports.",
            author: "Author",
            blogBody: `
                            <p>Too many people complicate their conditioning work and intervals by trying to get their athletes into the “fat-burning zone” or train at their lactic threshold, etc. The only thing is, those will be different for different people, and each prescribed interval session has a different effect based on how fit your athletes are at the time.</p>
                            <p>As a university strength and conditioning coach, I have to write conditioning programs for six different sports (12 teams). I dove into the research, read many books on the subject, and thought I was an expert in cardiovascular health and improvements. Then I tried to apply these specific protocols with the different teams, hoping each team would increase their fitness to the specific level required by their sport.</p>
                            <p>The prescriptions were too confusing and too hard to follow. I tried individualizing their conditioning work using the Maximal Aerobic Speed (MAS) protocol by basing their distances and interval times off their most recent fitness testing scores (Yo-Yo, mile run, Bronco, etc.). Most athletes didn’t do the workouts at all or just went for a 5-kilometer run instead. So, after all that hard research (which is great knowledge to have moving forward), at the end of the day, simplicity wins (Keep It Simple Stupid—KISS). Shocker.</p>
                            <p>Sprinting is good for conditioning and is obviously more “sports-specific” for running sports. Still, as mentioned above, I recommend putting these into a shuttle format so that athletes aren’t just all-out sprinting for 20–30 seconds (which would be close to 200 meters). This will reduce hamstring injuries for sure, and if there is one thing we all know, if an athlete gets hurt doing your conditioning work, that is bad news for you!</p>
                `
        }
    ]
}

export { site };