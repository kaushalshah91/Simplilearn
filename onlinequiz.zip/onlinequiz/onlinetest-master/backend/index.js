const express = require("express");
const cors = require('cors')
const app = express();
app.use(cors())

app.get("/quizlist", (request, response) =>{
    response.set('Access-Control-Allow-Origin', '*');
    quizlist = [
        {
          question: 'Northern Train Outfitters wants the From Name on the monthly Newsletter to come from a specific User who is set up in the Marketing Cloud. Which feature would be used to set up this From Name selection?',
          answer: ['Sender Profile', 'Content Information', 'Can-SPAM classification', 'Delivery Profile'],
          correct: 'Can-SPAM classification',
          done: false
        }, {
          question: 'Which is a fundamental component of coding responsive emails?',
          answer: ['CSS3 @media queries', 'Span Tags', 'SQL Queries', 'Anchor Tags'],
          correct: 'CSS3 @media queries',
          done: false
        }, {
          question: 'NTO wants to improve open rates. The email tracking team would like each of its campaign to have an engaging firm name, what should the email team setup for each campaign.',
          answer: ['Delivery Profiles', 'Sender Profiles', 'Profile Attributes', 'Send Flow'],
          correct: 'Sender Profiles',
          done: false
        }, {
          question: 'Northern Train Outfitters sends email order confirmations to customers who have made online purchases. These emails must follow the "Transactional" CAN-SPAM classification requirements. Which feature would a marketer use to classify a send under this CAN-SPAM classification?',
          answer: ['Send Classification', 'Send Definition', 'Delivery Profile', 'Sender Profile'],
          correct: 'Send Classification',
          done: false
        }, {
          question: 'Northern Trail Outfitters has a list of Platinum members containing 50,000 subscribers and a Lifetime Member list containing 20,000 subscribers; 7,000 subscribers in the Lifetime Member list also exist in the Platinum Member list. An email was deployed to the Platinum members, but the marketing team would now like to send the same email to the Lifetime Member list. Which feature should be used when sending the second email to ensure that the 7,000 subscribers that exist on both lists dont receive the same email twice?',
          answer: ['Exclusion Script', 'Suppression List', 'Domain Exclusion List', 'Exclusion List'],
          correct: 'Exclusion List',
          done: false
        }
      ]
      response.send(quizlist);
})

app.listen(3000, () => {
    console.log("Listen on the port 3000...");
});