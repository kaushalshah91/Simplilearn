# onlinetest

Navigate to `frontend` folder and find the readme.md for details (on running the app and documentation)
